<?php
/**
 * Helpers compartilhados para configurações gerais do painel (nome, WhatsApp,
 * API de esportes) e para o CRUD de planos. Usado por: admin_planos.php,
 * admin.php, premium.php, renovar.php e sportsschedule.php.
 */

if (!function_exists('pwb_config_path')) {
    function pwb_config_path() {
        return __DIR__ . '/../config.json';
    }
}

if (!function_exists('pwb_default_planos')) {
    function pwb_default_planos() {
        return [
            [
                'id' => 'basico',
                'nome' => 'Básico',
                'preco' => 'R$150',
                'periodo' => '/mês',
                'descricao' => 'Ideal para usuários individuais',
                'features' => ['Streaming em HD', '1 dispositivo', 'Filmes e Séries', 'TV ao vivo'],
                'popular' => false,
                'mensagem_whatsapp' => ''
            ],
            [
                'id' => 'premium',
                'nome' => 'Premium',
                'preco' => 'R$360',
                'periodo' => '/3 meses',
                'descricao' => 'Perfeito para casais e famílias',
                'features' => ['Streaming em HD e 4K', '3 dispositivos simultâneos', 'Conteúdo exclusivo', 'Esportes ao vivo premium'],
                'popular' => true,
                'mensagem_whatsapp' => ''
            ],
            [
                'id' => 'familiar',
                'nome' => 'Familiar',
                'preco' => 'R$600',
                'periodo' => '/6 meses',
                'descricao' => 'A melhor opção a longo prazo',
                'features' => ['Streaming em HD e 4K', '3 dispositivos simultâneos', 'Conteúdo exclusivo', 'Suporte prioritário 24/7'],
                'popular' => false,
                'mensagem_whatsapp' => ''
            ]
        ];
    }
}

if (!function_exists('pwb_load_config')) {
    function pwb_load_config() {
        $path = pwb_config_path();
        $config = file_exists($path) ? json_decode(file_get_contents($path), true) : [];
        if (!is_array($config)) {
            $config = [];
        }

        // Garante valores padrão para não quebrar telas antigas de config.json
        $defaults = [
            'usuario' => 'admin',
            'senha' => 'admin',
            'logo' => '',
            'background' => '',
            'nome_painel' => 'GLOBAL WEB',
            'whatsapp_numero' => '',
            'sports_api_url' => 'https://painelwb.com.br/api/link.php?token=948608107e47c6df72fffb72caa07842',
            'tmdb_api_key' => '54a47dfd36406757c9a6b7a0e3fd9cdc',
            'planos' => pwb_default_planos()
        ];

        foreach ($defaults as $key => $value) {
            if (!isset($config[$key]) || $config[$key] === '' && $key === 'planos') {
                $config[$key] = $value;
            }
        }
        if (empty($config['planos']) || !is_array($config['planos'])) {
            $config['planos'] = pwb_default_planos();
        }

        return $config;
    }
}

if (!function_exists('pwb_save_config')) {
    function pwb_save_config($config) {
        return file_put_contents(pwb_config_path(), json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
}

if (!function_exists('pwb_whatsapp_link')) {
    /**
     * Monta o link do WhatsApp para um plano específico.
     * Usa a mensagem customizada do plano (se houver) ou gera uma mensagem
     * padrão de acordo com o modo ('assinar' ou 'renovar'). Se o usuário
     * estiver logado (cliente já com conta no sistema), o nome de usuário
     * dele é incluído no final da mensagem, pra facilitar identificar quem
     * está pedindo ao receber no WhatsApp.
     */
    function pwb_whatsapp_link($numero, $plano, $modo, $nomePainel, $usuario = '') {
        $numero = preg_replace('/\D+/', '', (string) $numero);

        if (!empty($plano['mensagem_whatsapp'])) {
            $mensagem = $plano['mensagem_whatsapp'];
        } elseif ($modo === 'renovar') {
            $mensagem = "Olá! Quero renovar minha assinatura {$nomePainel} no plano {$plano['nome']} ({$plano['preco']}{$plano['periodo']}).";
        } else {
            $mensagem = "Olá! Tenho interesse no plano {$plano['nome']} ({$plano['preco']}{$plano['periodo']}) do {$nomePainel}.";
        }

        $usuario = trim((string) $usuario);
        if ($usuario !== '') {
            $mensagem .= " Meu usuário é: {$usuario}.";
        }

        return 'https://wa.me/' . $numero . '?text=' . rawurlencode($mensagem);
    }
}
