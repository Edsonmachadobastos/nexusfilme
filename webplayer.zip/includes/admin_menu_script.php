<script>
  (function () {
    const toggle  = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    function openMenu()  { sidebar.classList.add('active'); overlay.classList.add('active'); }
    function closeMenu() { sidebar.classList.remove('active'); overlay.classList.remove('active'); }

    toggle?.addEventListener('click', () => sidebar.classList.contains('active') ? closeMenu() : openMenu());
    overlay?.addEventListener('click', closeMenu);
    sidebar?.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));

    // Esconde mensagens de sucesso automaticamente
    const successEl = document.getElementById('success-message');
    if (successEl) {
      setTimeout(() => {
        successEl.style.opacity = '0';
        setTimeout(() => { successEl.style.display = 'none'; }, 500);
      }, 3500);
    }
  })();
</script>
