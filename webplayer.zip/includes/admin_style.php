<?php
/**
 * Tema visual único do painel administrativo — Azul Escuro Premium.
 * Incluído por: dashboard.php, admin.php, admin_planos.php, servidores.php,
 * admin_jogos.php. Mantém a MESMA paleta de cores em todas as telas do admin.
 */
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  :root {
    --bg:        #050810;
    --surface:   #0a0f1c;
    --surface2:  #0f1526;
    --hover:     #16203a;
    --border:    #1a2440;
    --border-soft: #141c33;
    --accent:      #2f6fed;
    --accent2:     #1a4fd6;
    --accent-light:#5b8def;
    --accent-glow: rgba(47,111,237,.35);
    --teal:      #22d3ee;
    --amber:     #fbbf24;
    --red:       #f87171;
    --green:     #34d399;
    --text:      #eef2fb;
    --dim:       #92a0c4;
    --faint:     #576088;
    --sidebar-w: 252px;
  }
  *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
  html { color-scheme: dark; }
  body {
    font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
    background: var(--bg);
    background-image:
      radial-gradient(900px 500px at 8% -5%,   rgba(47,111,237,.16), transparent 55%),
      radial-gradient(700px 460px at 100% 0%,  rgba(34,211,238,.06), transparent 50%),
      radial-gradient(800px 600px at 50% 120%, rgba(26,79,214,.10), transparent 55%);
    background-attachment: fixed;
    color: var(--text);
    min-height: 100vh;
    display: flex;
    -webkit-font-smoothing: antialiased;
    letter-spacing: -.01em;
  }
  a { color: inherit; text-decoration: none; }
  ::-webkit-scrollbar { width: 10px; height: 10px; }
  ::-webkit-scrollbar-track { background: var(--bg); }
  ::-webkit-scrollbar-thumb { background: var(--surface2); border-radius: 10px; border: 2px solid var(--bg); }
  ::-webkit-scrollbar-thumb:hover { background: var(--hover); }

  /* ── SIDEBAR ── */
  .sidebar {
    width: var(--sidebar-w);
    background: linear-gradient(180deg, #0a0f1e 0%, #060a15 100%);
    border-right: 1px solid var(--border-soft);
    height: 100vh;
    position: fixed;
    top: 0; left: 0;
    display: flex;
    flex-direction: column;
    z-index: 100;
    transition: left .28s ease;
    box-shadow: 4px 0 30px rgba(0,0,0,.25);
  }
  .sidebar-logo {
    padding: 24px 22px 20px;
    border-bottom: 1px solid var(--border-soft);
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .sidebar-logo img { height: 38px; width: auto; object-fit: contain; border-radius: 8px; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
  .sidebar-logo .brand { font-size: .98rem; font-weight: 800; color: var(--text); letter-spacing: -.02em; }
  nav { padding: 14px 12px; flex: 1; display: flex; flex-direction: column; gap: 4px; overflow-y: auto; }
  .nav-item {
    display: flex; align-items: center; gap: 12px;
    padding: 11px 14px; border-radius: 10px;
    font-size: .875rem; font-weight: 500; color: var(--dim);
    border: 1px solid transparent; transition: all .18s ease;
  }
  .nav-item i { width: 18px; text-align: center; font-size: .92rem; }
  .nav-item:hover        { background: var(--hover); color: var(--text); }
  .nav-item.active       {
    background: linear-gradient(90deg, var(--accent2), var(--accent));
    color: #fff;
    box-shadow: 0 6px 18px -4px var(--accent-glow);
    font-weight: 600;
  }
  .nav-item.nav-logout:hover { background: rgba(248,113,113,.1); color: var(--red); }
  .nav-divider { height: 1px; background: var(--border-soft); margin: 10px 10px; }

  /* ── MAIN ── */
  .main { margin-left: var(--sidebar-w); flex: 1; padding: 30px 34px 48px; max-width: 100%; }

  /* ── TOPBAR ── */
  .topbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px; gap: 1rem; flex-wrap: wrap; }
  .topbar-left h1 { font-size: 1.6rem; font-weight: 800; letter-spacing: -.02em; }
  .topbar-left p  { color: var(--faint); font-size: .86rem; margin-top: 4px; }
  .topbar-right { display: flex; align-items: center; gap: .6rem; flex-shrink: 0; }

  .btn {
    display: inline-flex; align-items: center; gap: .45rem;
    padding: .58rem 1.1rem; border-radius: 9px; font-size: .83rem; font-weight: 600;
    border: none; cursor: pointer; font-family: inherit; transition: all .18s ease; text-decoration: none;
  }
  .btn-ghost   { background: var(--surface2); color: var(--dim); border: 1px solid var(--border); }
  .btn-ghost:hover   { background: var(--hover); color: var(--text); border-color: var(--accent); }
  .btn-primary { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff; box-shadow: 0 8px 20px -8px var(--accent-glow); }
  .btn-primary:hover { filter: brightness(1.1); transform: translateY(-1px); box-shadow: 0 10px 26px -8px var(--accent-glow); }
  .btn-danger  { background: rgba(248,113,113,.12); color: var(--red); border: 1px solid rgba(248,113,113,.3); }
  .btn-danger:hover  { background: rgba(248,113,113,.2); }
  .btn-block { width: 100%; justify-content: center; }
  .hamburger { display: none; }

  /* ── CARD / PANEL ── */
  .panel {
    background: linear-gradient(180deg, var(--surface), var(--surface2));
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 24px 26px;
    margin-bottom: 24px;
    box-shadow: 0 12px 34px -18px rgba(0,0,0,.6);
  }
  .panel h2 { font-size: 1.3rem; font-weight: 800; margin-bottom: 6px; letter-spacing: -.01em; }
  .panel .panel-desc { color: var(--faint); font-size: .85rem; margin-bottom: 18px; line-height: 1.5; }

  /* ── STATS GRID (usado no dashboard) ── */
  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }
  .stat-card {
    background: linear-gradient(160deg, var(--surface), var(--surface2));
    border: 1px solid var(--border); border-radius: 14px;
    padding: 20px 22px; display: flex; align-items: center; gap: 16px;
    transition: border-color .2s, transform .2s, box-shadow .2s; text-decoration: none; color: inherit;
    box-shadow: 0 10px 28px -20px rgba(0,0,0,.7);
  }
  .stat-card:hover { border-color: var(--accent); transform: translateY(-3px); box-shadow: 0 16px 32px -16px var(--accent-glow); }
  .stat-icon { width: 46px; height: 46px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.15rem; flex-shrink: 0; }
  .icon-blue   { background: rgba(47,111,237,.14); color: var(--accent-light); }
  .icon-teal   { background: rgba(34,211,238,.12); color: var(--teal); }
  .icon-amber  { background: rgba(251,191,36,.12);  color: var(--amber); }
  .icon-red    { background: rgba(248,113,113,.12);  color: var(--red); }
  .stat-info .value { font-size: 1.75rem; font-weight: 800; line-height: 1; letter-spacing: -.02em; }
  .stat-info .label { font-size: .78rem; color: var(--faint); margin-top: 5px; font-weight: 500; }

  .section-title { font-size: .7rem; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; color: var(--faint); margin-bottom: 14px; }
  .actions-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 28px; }
  .action-card {
    background: linear-gradient(160deg, var(--surface), var(--surface2)); border: 1px solid var(--border); border-radius: 14px; padding: 22px 18px;
    display: flex; flex-direction: column; align-items: flex-start; gap: 10px; cursor: pointer;
    transition: all .2s ease; text-decoration: none; color: inherit;
  }
  .action-card:hover { background: var(--hover); border-color: var(--accent); transform: translateY(-3px); box-shadow: 0 14px 28px -16px var(--accent-glow); }
  .action-card .action-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.05rem; }
  .action-card .action-label { font-size: .885rem; font-weight: 700; }
  .action-card .action-desc  { font-size: .76rem; color: var(--faint); }

  .info-card { background: linear-gradient(160deg, var(--surface), var(--surface2)); border: 1px solid var(--border); border-radius: 14px; padding: 20px 22px; }
  .info-row { display: flex; justify-content: space-between; align-items: center; padding: 11px 0; border-bottom: 1px solid var(--border-soft); font-size: .875rem; }
  .info-row:last-child { border-bottom: none; }
  .info-row .info-key { color: var(--faint); font-size: .78rem; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; }
  .info-row .info-val { color: var(--text); font-weight: 600; }
  .badge { display: inline-block; padding: .28rem .7rem; border-radius: 999px; font-size: .7rem; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; }
  .badge-teal  { background: rgba(34,211,238,.12); color: var(--teal); }
  .badge-amber { background: rgba(251,191,36,.12);  color: var(--amber); }
  .badge-red   { background: rgba(248,113,113,.12); color: var(--red); }

  /* ── FORMS ── */
  .form-group { margin-bottom: 18px; }
  .form-label { display: block; font-size: .8rem; font-weight: 600; color: var(--dim); margin-bottom: 7px; }
  .form-hint  { font-size: .74rem; color: var(--faint); margin-top: 6px; line-height: 1.4; }
  .form-input, .form-textarea, .form-select {
    width: 100%; padding: 11px 15px; border-radius: 9px;
    background: var(--surface2); border: 1px solid var(--border); color: var(--text);
    font-family: inherit; font-size: .9rem; transition: border-color .18s ease, box-shadow .18s ease;
  }
  .form-input:focus, .form-textarea:focus, .form-select:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(47,111,237,.15); }
  .form-textarea { resize: vertical; min-height: 90px; }
  .form-file { color: var(--dim); font-size: .85rem; }
  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .preview-thumb { height: 64px; width: auto; border-radius: 8px; background: var(--surface2); border: 1px solid var(--border); padding: 6px; margin-top: 10px; }
  .preview-wide { width: 100%; max-width: 420px; height: 130px; object-fit: cover; border-radius: 8px; border: 1px solid var(--border); margin-top: 10px; }

  /* ── ALERTS ── */
  .alert { padding: 13px 17px; border-radius: 10px; font-size: .85rem; margin-bottom: 18px; }
  .alert-success { background: rgba(34,211,238,.08); color: var(--teal); border: 1px solid rgba(34,211,238,.22); }
  .alert-error   { background: rgba(248,113,113,.08); color: var(--red); border: 1px solid rgba(248,113,113,.22); }
  .alert-warn    { background: rgba(251,191,36,.08); color: var(--amber); border: 1px solid rgba(251,191,36,.22); }

  /* ── TABLE ── */
  .table-wrap { overflow-x: auto; border-radius: 14px; border: 1px solid var(--border); }
  table.admin-table { width: 100%; border-collapse: collapse; background: var(--surface); }
  table.admin-table th {
    text-align: left; padding: 13px 16px; background: var(--surface2); color: var(--dim);
    font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; font-weight: 700;
  }
  table.admin-table td { padding: 13px 16px; border-top: 1px solid var(--border-soft); font-size: .875rem; color: var(--text); }
  table.admin-table tr:hover td { background: var(--hover); }

  /* ── OVERLAY mobile ── */
  .overlay { display:none; position:fixed; inset:0; background:rgba(3,5,12,.8); backdrop-filter:blur(3px); z-index:99; }
  .overlay.active { display:block; }

  /* ── modal flutuante (edição) ── */
  .modal {
    display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    z-index: 1000; width: 92%; max-width: 420px;
    background: linear-gradient(160deg, var(--surface), var(--surface2)); border: 1px solid var(--border); border-radius: 16px;
    padding: 26px; box-shadow: 0 26px 70px rgba(0,0,0,.55);
  }
  .modal.active { display: block; }
  .modal h4 { font-size: 1.08rem; font-weight: 800; margin-bottom: 16px; }

  /* ── RESPONSIVE ── */
  @media (max-width: 768px) {
    .sidebar { left: -100%; }
    .sidebar.active { left: 0; }
    .main { margin-left: 0; padding: 16px 14px 40px; }
    .hamburger { display: flex; align-items: center; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
    .stat-card { padding: 14px 14px; }
    .stat-info .value { font-size: 1.4rem; }
    .form-row { grid-template-columns: 1fr; }
  }
</style>
