<?php
/**
 * Renderiza a grade de planos.
 * Espera as variáveis já definidas por quem faz o include:
 *   $planos          -> array de planos (config['planos'])
 *   $whatsapp_numero -> número usado no link do WhatsApp
 *   $nome_painel     -> nome do painel (usado na mensagem padrão)
 *   $pwb_modo        -> 'assinar' ou 'renovar' (define o texto do botão e a mensagem padrão)
 *   $pwb_usuario     -> (opcional) usuário do cliente logado, incluído na mensagem do WhatsApp
 */
$pwb_modo = $pwb_modo ?? 'assinar';
$pwb_usuario = $pwb_usuario ?? '';
$botaoTexto = $pwb_modo === 'renovar' ? 'Renovar Agora' : 'Escolher Plano';
?>
<div class="grid md:grid-cols-3 gap-8">
    <?php foreach ($planos as $index => $plano): ?>
        <?php
            $ehPopular = !empty($plano['popular']);
            $link = pwb_whatsapp_link($whatsapp_numero, $plano, $pwb_modo, $nome_painel, $pwb_usuario);
            $cardClasses = $ehPopular
                ? 'plan-card plan-popular bg-gray-900/80 rounded-2xl p-8 relative z-10'
                : 'plan-card bg-gray-900/60 rounded-2xl p-8 relative';
        ?>
        <div class="<?php echo $cardClasses; ?>" data-aos="fade-up" data-aos-delay="<?php echo 100 + ($index * 100); ?>">
            <?php if ($ehPopular): ?>
                <div class="absolute -top-4 left-0 right-0 flex justify-center">
                    <span class="bg-gradient-to-r from-yellow-500 to-yellow-600 text-black px-4 py-1 rounded-full text-sm font-bold">
                        MAIS POPULAR
                    </span>
                </div>
            <?php endif; ?>

            <div class="space-y-4">
                <h3 class="text-2xl font-bold"><?php echo htmlspecialchars($plano['nome']); ?></h3>
                <div class="text-4xl font-bold">
                    <?php echo htmlspecialchars($plano['preco']); ?><span class="text-lg text-gray-400"><?php echo htmlspecialchars($plano['periodo']); ?></span>
                </div>
                <?php if (!empty($plano['descricao'])): ?>
                    <p class="text-gray-400 pb-4"><?php echo htmlspecialchars($plano['descricao']); ?></p>
                <?php endif; ?>
            </div>

            <div class="border-t border-gray-700 my-6"></div>

            <?php if (!empty($plano['features'])): ?>
                <ul class="space-y-4 mb-12">
                    <?php foreach ($plano['features'] as $feature): ?>
                        <li class="flex items-start gap-3">
                            <i class="fas fa-check text-green-500"></i>
                            <span><?php echo htmlspecialchars($feature); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <a href="<?php echo htmlspecialchars($link); ?>" target="_blank"
               class="w-full inline-flex items-center justify-center gap-2 <?php echo $ehPopular
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 transform hover:scale-105'
                    : 'bg-blue-600 hover:bg-blue-700'; ?> text-white py-3 rounded-xl transition duration-300">
                <i class="fab fa-whatsapp"></i>
                <span><?php echo $botaoTexto; ?></span>
            </a>
        </div>
    <?php endforeach; ?>
</div>
