<?php
// Espera $i (índice) e $plano (array) definidos por quem faz o include.
$featuresTexto = implode("\n", $plano['features'] ?? []);
?>
<div class="plano-card">
    <button type="button" class="remove-plano">✕ Remover</button>

    <input type="hidden" name="plano_id[<?php echo $i; ?>]" value="<?php echo htmlspecialchars($plano['id'] ?? ''); ?>">

    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Nome do plano</label>
            <input type="text" name="nome[<?php echo $i; ?>]" value="<?php echo htmlspecialchars($plano['nome'] ?? ''); ?>"
                   placeholder="Ex: Premium" class="form-input">
        </div>
        <div class="form-row" style="grid-template-columns: 1fr 1fr;">
            <div class="form-group">
                <label class="form-label">Preço</label>
                <input type="text" name="preco[<?php echo $i; ?>]" value="<?php echo htmlspecialchars($plano['preco'] ?? ''); ?>"
                       placeholder="Ex: R$150" class="form-input">
            </div>
            <div class="form-group">
                <label class="form-label">Período</label>
                <input type="text" name="periodo[<?php echo $i; ?>]" value="<?php echo htmlspecialchars($plano['periodo'] ?? ''); ?>"
                       placeholder="Ex: /mês" class="form-input">
            </div>
        </div>
    </div>

    <div class="form-group">
        <label class="form-label">Descrição curta</label>
        <input type="text" name="descricao[<?php echo $i; ?>]" value="<?php echo htmlspecialchars($plano['descricao'] ?? ''); ?>"
               placeholder="Ex: Ideal para usuários individuais" class="form-input">
    </div>

    <div class="form-group">
        <label class="form-label">Benefícios (um por linha)</label>
        <textarea name="features[<?php echo $i; ?>]" rows="4" placeholder="Streaming em HD&#10;1 dispositivo&#10;Filmes e Séries"
                  class="form-textarea"><?php echo htmlspecialchars($featuresTexto); ?></textarea>
    </div>

    <div class="form-group">
        <label class="form-label">Mensagem personalizada do WhatsApp <span style="font-weight:400; color:var(--faint);">(opcional)</span></label>
        <input type="text" name="mensagem_whatsapp[<?php echo $i; ?>]" value="<?php echo htmlspecialchars($plano['mensagem_whatsapp'] ?? ''); ?>"
               placeholder="Se vazio, uma mensagem padrão é gerada automaticamente" class="form-input">
    </div>

    <div class="checkbox-row">
        <input type="checkbox" id="popular-<?php echo $i; ?>" name="popular[]" value="<?php echo $i; ?>" <?php echo !empty($plano['popular']) ? 'checked' : ''; ?>>
        <label for="popular-<?php echo $i; ?>">Marcar como "Mais Popular"</label>
    </div>
</div>
