<?php
/**
 * Menu lateral do painel administrativo.
 * Espera (opcionais, com fallback seguro):
 *   $active    string - chave da página atual: dashboard|servidores|planos|jogos|admin
 *   $logoPath  string - caminho da logo configurada
 */
$active = $active ?? '';
$logoPath = $logoPath ?? '';
function admin_nav_class($key, $active) {
    return 'nav-item' . ($key === $active ? ' active' : '');
}
?>
<div class="overlay" id="overlay"></div>

<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <?php if (!empty($logoPath)): ?>
      <img src="<?= htmlspecialchars($logoPath) ?>" alt="Logo">
    <?php endif; ?>
    <span class="brand">Painel Admin</span>
  </div>
  <nav>
    <a href="dashboard.php" class="<?= admin_nav_class('dashboard', $active) ?>"><i class="fas fa-gauge-high"></i><span>Dashboard</span></a>
    <a href="servidores.php" class="<?= admin_nav_class('servidores', $active) ?>"><i class="fas fa-server"></i><span>Servidores</span></a>
    <a href="admin_planos.php" class="<?= admin_nav_class('planos', $active) ?>"><i class="fas fa-tags"></i><span>Planos</span></a>
    <a href="admin_jogos.php" class="<?= admin_nav_class('jogos', $active) ?>"><i class="fas fa-futbol"></i><span>Jogos do Dia</span></a>
    <a href="admin.php" class="<?= admin_nav_class('admin', $active) ?>"><i class="fas fa-sliders"></i><span>Configurações</span></a>
    <div class="nav-divider"></div>
    <a href="logoutvs.php" class="nav-item nav-logout"><i class="fas fa-right-from-bracket"></i><span>Sair</span></a>
  </nav>
</aside>
